/*! licenses: /vendor.LICENSE.txt */
import{aX as s}from"./main-BHmO6O7Z.js";import{j as n}from"./echoes-Bqgy_wsv.js";import{s as e}from"./vendor-BJNazcLv.js";function p(t){function o(i){const r=e();return n.jsx(t,{...i,...r,"data-component":"component-with-quality-profiles-props"})}return o.displayName=s(t,"withQualityProfilesContext"),o}function f(){return e()}export{f as u,p as w};
//# sourceMappingURL=qualityProfilesContext-BxZ37yW2.js.map
