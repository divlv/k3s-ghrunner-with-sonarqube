/*! licenses: /vendor.LICENSE.txt */
import{j as a,aN as o}from"./echoes-Bqgy_wsv.js";import"./vendor-BJNazcLv.js";import{eg as t,at as n}from"./main-BHmO6O7Z.js";function m(s){return a.jsxs(t,{...s,"data-component":"contains-ai-code-badge",children:[a.jsx(o,{className:"sw-mr-1 sw-fon"}),n("contains_ai_code")]})}export{m as C};
//# sourceMappingURL=ContainsAICodeBadge-BR1s0GOG.js.map
