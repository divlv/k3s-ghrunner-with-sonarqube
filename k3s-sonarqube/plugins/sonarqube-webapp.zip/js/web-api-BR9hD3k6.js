/*! licenses: /vendor.LICENSE.txt */
import{aB as t,aA as a}from"./main-BHmO6O7Z.js";function n(e=!0){return t("/api/webservices/list",{include_internals:e}).then(r=>r.webServices).catch(a)}function s(e,r){return t("/api/webservices/response_example",{controller:e,action:r}).catch(a)}function i(){return t("/api/v2/api-docs").catch(a)}export{i as a,s as b,n as f};
//# sourceMappingURL=web-api-BR9hD3k6.js.map
