/*! licenses: /vendor.LICENSE.txt */
import{c as o,e as r,a as t,t as e}from"./main-BHmO6O7Z.js";import"./echoes-Bqgy_wsv.js";const n=o(r,{target:"e8v18me0"})("color:",t("linkDefault"),";border-bottom:",e("default","linkDefault"),";",{fontWeight:"600"}," ",{textDecorationLine:"none"}," &:hover,&:focus,&:active{color:",t("linkActive"),";border-bottom:",e("default","linkDefault"),";}");export{n as B};
//# sourceMappingURL=ButtonLink-BjrNkYVl.js.map
