/*! licenses: /vendor.LICENSE.txt */
import"./vendor-BJNazcLv.js";import{cN as o,cD as e}from"./main-BHmO6O7Z.js";import"./echoes-Bqgy_wsv.js";function i(r){return r instanceof Response?o(r).then(e,()=>{}):typeof r=="string"?Promise.resolve(r).then(e):Promise.resolve()}export{i as a};
//# sourceMappingURL=globalMessages-4Qrx0V8I.js.map
