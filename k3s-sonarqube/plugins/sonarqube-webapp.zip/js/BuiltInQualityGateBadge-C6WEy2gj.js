/*! licenses: /vendor.LICENSE.txt */
import"./vendor-BJNazcLv.js";import{eg as a,at as i}from"./main-BHmO6O7Z.js";import{j as e}from"./echoes-Bqgy_wsv.js";function s({className:t}){return e.jsx(a,{className:t,"data-component":"built-in-quality-gate-badge",children:i("quality_gates.built_in")})}export{s as B};
//# sourceMappingURL=BuiltInQualityGateBadge-C6WEy2gj.js.map
