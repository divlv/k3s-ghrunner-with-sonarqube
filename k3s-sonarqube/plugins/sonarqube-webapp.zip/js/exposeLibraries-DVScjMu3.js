/*! licenses: /vendor.LICENSE.txt */
import"./vendor-BJNazcLv.js";import{cb as s,aA as t,eH as o,bs as r,az as e,cN as p,bZ as i,kV as l,aB as m,cK as b,cx as c,at as n,b7 as d}from"./main-BHmO6O7Z.js";import"./echoes-Bqgy_wsv.js";import"./lodash-BBvWO61n.js";import"./highlightjs-BXzlIbdZ.js";import"./datefns-BO8xBBw8.js";const J=()=>{const a=window;a.SonarRequest={request:c,get:b,getJSON:m,getText:l,omitNil:i,parseError:p,post:e,postJSON:r,postJSONBody:o,throwGlobalError:t,addGlobalSuccessMessage:s},a.t=n,a.tp=d};export{J as default};
//# sourceMappingURL=exposeLibraries-DVScjMu3.js.map
