/*! licenses: /vendor.LICENSE.txt */
import{c as e,B as r,a as o,b as t,O as a,t as n}from"./main-BHmO6O7Z.js";const c=e(r,{target:"e1m7u0md0"})("--background:",o("dangerButtonSecondary"),";--backgroundHover:",o("dangerButtonSecondaryHover"),";--color:",t("dangerButtonSecondary"),";--focus:",o("dangerButtonSecondaryFocus",a),";--border:",n("default","dangerButtonSecondaryBorder"),";");export{c as D};
//# sourceMappingURL=DangerButtonSecondary-CPvbjEo_.js.map
