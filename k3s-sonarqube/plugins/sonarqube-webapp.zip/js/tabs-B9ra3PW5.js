/*! licenses: /vendor.LICENSE.txt */
function t(a){return`tabpanel-${a}`}function n(a){return`tab-${a}`}export{t as a,n as g};
//# sourceMappingURL=tabs-B9ra3PW5.js.map
