/*! licenses: /vendor.LICENSE.txt */
import"./vendor-BJNazcLv.js";import{aT as n,kt as a}from"./main-BHmO6O7Z.js";import{j as e}from"./echoes-Bqgy_wsv.js";function f({name:t,language:o,children:r,...i}){return e.jsx(n,{to:a(t,o),...i,"data-component":"profile-link",children:r})}export{f as P};
//# sourceMappingURL=ProfileLink-C8BJWA2B.js.map
