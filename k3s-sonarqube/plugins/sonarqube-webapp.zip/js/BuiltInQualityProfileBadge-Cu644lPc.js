/*! licenses: /vendor.LICENSE.txt */
import"./vendor-BJNazcLv.js";import{eg as n,at as i,be as o}from"./main-BHmO6O7Z.js";import{j as e}from"./echoes-Bqgy_wsv.js";function p({className:r,tooltip:a=!0}){const t=e.jsx(n,{className:r,variant:"default",children:i("quality_profiles.built_in")});return a?e.jsx(o,{content:i("quality_profiles.built_in.description"),children:t}):t}export{p as B};
//# sourceMappingURL=BuiltInQualityProfileBadge-Cu644lPc.js.map
