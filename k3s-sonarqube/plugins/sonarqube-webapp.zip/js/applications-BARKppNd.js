/*! licenses: /vendor.LICENSE.txt */
import{aC as n,aD as o,aE as i,aF as s,ij as u}from"./main-BHmO6O7Z.js";import{a as r,d as p}from"./application-FGte6hvu.js";const y=n(e=>o({queryKey:["application","leak",e],queryFn:()=>r(e)}));function m(){const e=i();return s({mutationFn:a=>p(a),onSuccess:(a,t)=>{u(t,e)}})}export{m as a,y as u};
//# sourceMappingURL=applications-BARKppNd.js.map
