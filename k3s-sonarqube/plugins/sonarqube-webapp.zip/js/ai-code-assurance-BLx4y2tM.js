/*! licenses: /vendor.LICENSE.txt */
import{aC as o,aD as s}from"./main-BHmO6O7Z.js";import{g as n,c as y,d}from"./AIAssuredIcon-CSKRyZec.js";const a="project-ai-code-assurance",_=o(({project:e,branch:t})=>s({queryKey:[a,e.key,"code-assurance","branch",t],queryFn:({queryKey:[r,u,i,A,c]})=>y(u,c)})),j=o(({project:e})=>s({queryKey:[a,e.key,"containsAiCode"],queryFn:({queryKey:[t,r]})=>n(r)})),P=o(({project:e})=>s({queryKey:[a,e.key,"detectedAiCode"],queryFn:({queryKey:[t,r]})=>d(r)}));export{P as a,j as b,_ as u};
//# sourceMappingURL=ai-code-assurance-BLx4y2tM.js.map
