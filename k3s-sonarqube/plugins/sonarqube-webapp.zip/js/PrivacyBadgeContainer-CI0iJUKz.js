/*! licenses: /vendor.LICENSE.txt */
import{be as n,at as t,d as r}from"./main-BHmO6O7Z.js";import{j as e}from"./echoes-Bqgy_wsv.js";function d({className:i,qualifier:s,visibility:a}){return e.jsx(n,{content:t("visibility",a,"description",s),"data-component":"privacy-badge-container",children:e.jsx("div",{className:r("badge",i),children:t("visibility",a)})})}export{d as P};
//# sourceMappingURL=PrivacyBadgeContainer-CI0iJUKz.js.map
