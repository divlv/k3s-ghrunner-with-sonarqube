/*! licenses: /vendor.LICENSE.txt */
import{c as r,B as e,a as t,b as o,O as a,t as n}from"./main-BHmO6O7Z.js";const d=r(e,{target:"e1yk8d5v0"})("--background:",t("dangerButton"),";--backgroundHover:",t("dangerButtonHover"),";--color:",o("dangerButton"),";--focus:",t("dangerButtonFocus",a),";--border:",n("default","transparent"),";");export{d as D};
//# sourceMappingURL=DangerButtonPrimary-CzP7hi_c.js.map
