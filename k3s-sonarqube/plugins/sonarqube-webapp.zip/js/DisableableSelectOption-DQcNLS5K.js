/*! licenses: /vendor.LICENSE.txt */
import{be as t}from"./main-BHmO6O7Z.js";import{j as s}from"./echoes-Bqgy_wsv.js";function d(o){const{option:e,disableTooltipOverlay:n,disabledReason:l,className:a=""}=o,i=e.label||e.value;return e.isDisabled?s.jsx(t,{content:n(),side:"left",children:s.jsxs("span",{className:a,children:[i,l!==void 0&&s.jsxs("em",{className:"small sw-ml-1",children:["(",l,")"]})]})}):s.jsx("span",{className:a,children:i})}export{d as D};
//# sourceMappingURL=DisableableSelectOption-DQcNLS5K.js.map
