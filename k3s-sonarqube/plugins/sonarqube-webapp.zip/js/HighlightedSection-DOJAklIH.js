/*! licenses: /vendor.LICENSE.txt */
import{c as e,t as r,a as o}from"./main-BHmO6O7Z.js";const i=e("div",{target:"e1nzshkt0"})("border:",r("default","highlightedSectionBorder"),";background:",o("highlightedSection"),";",{boxSizing:"border-box"}," ",{display:"flex",flexDirection:"column"}," ",{gap:"1rem"}," ",{padding:"2rem"}," ",{borderRadius:"0.5rem"},";");export{i as H};
//# sourceMappingURL=HighlightedSection-DOJAklIH.js.map
