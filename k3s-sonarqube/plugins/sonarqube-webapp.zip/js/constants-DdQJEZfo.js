/*! licenses: /vendor.LICENSE.txt */
const L={ALL:"__ALL__",ALL_EXCEPT_PENDING:"__ALL_EXCEPT_PENDING__"},_="ALL_TYPES",E={ALL:"__ALL__",ONLY_CURRENTS:"CURRENTS"},A={status:L.ALL_EXCEPT_PENDING,taskType:_,currents:E.ALL,minSubmittedAt:void 0,maxExecutedAt:void 0,query:""},s=250,t=100;export{_ as A,E as C,A as D,t as P,L as S,s as a};
//# sourceMappingURL=constants-DdQJEZfo.js.map
