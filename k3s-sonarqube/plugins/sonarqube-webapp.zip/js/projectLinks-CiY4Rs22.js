/*! licenses: /vendor.LICENSE.txt */
import{aB as n,aA as r,bs as a,az as i}from"./main-BHmO6O7Z.js";function o(t){return n("/api/project_links/search",{projectKey:t}).then(e=>e.links,r)}function c(t){return i("/api/project_links/delete",{id:t}).catch(r)}function p(t){return a("/api/project_links/create",t).then(e=>e.link,r)}export{p as c,c as d,o as g};
//# sourceMappingURL=projectLinks-CiY4Rs22.js.map
